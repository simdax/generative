Sound pack downloaded from Freesound.org
----------------------------------------

This pack of sounds contains sounds by TicTacShutUp ( http://www.freesound.org/people/TicTacShutUp/  )
You can find this pack online at: http://www.freesound.org/people/TicTacShutUp/packs/17/


License details
---------------

Sampling+: http://creativecommons.org/licenses/sampling+/1.0/
Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/
Attribution: http://creativecommons.org/licenses/by/3.0/
Attribution Noncommercial: http://creativecommons.org/licenses/by-nc/3.0/


Sounds in this pack
-------------------

  * 432__TicTacShutUp__prac_perc_4.wav
    * url: http://www.freesound.org/people/TicTacShutUp/sounds/432/
    * license: Attribution
  * 449__TicTacShutUp__prac_tom.wav
    * url: http://www.freesound.org/people/TicTacShutUp/sounds/449/
    * license: Attribution
  * 448__TicTacShutUp__prac_tom_light.wav
    * url: http://www.freesound.org/people/TicTacShutUp/sounds/448/
    * license: Attribution
  * 447__TicTacShutUp__prac_snare.wav
    * url: http://www.freesound.org/people/TicTacShutUp/sounds/447/
    * license: Attribution
  * 446__TicTacShutUp__prac_snare_roll.wav
    * url: http://www.freesound.org/people/TicTacShutUp/sounds/446/
    * license: Attribution
  * 445__TicTacShutUp__prac_snare_roll_short.wav
    * url: http://www.freesound.org/people/TicTacShutUp/sounds/445/
    * license: Attribution
  * 444__TicTacShutUp__prac_snare_roll_short_2.wav
    * url: http://www.freesound.org/people/TicTacShutUp/sounds/444/
    * license: Attribution
  * 443__TicTacShutUp__prac_snare_rimshot.wav
    * url: http://www.freesound.org/people/TicTacShutUp/sounds/443/
    * license: Attribution
  * 442__TicTacShutUp__prac_snare_rimshot_2.wav
    * url: http://www.freesound.org/people/TicTacShutUp/sounds/442/
    * license: Attribution
  * 441__TicTacShutUp__prac_snare_rim.wav
    * url: http://www.freesound.org/people/TicTacShutUp/sounds/441/
    * license: Attribution
  * 440__TicTacShutUp__prac_snare_off.wav
    * url: http://www.freesound.org/people/TicTacShutUp/sounds/440/
    * license: Attribution
  * 439__TicTacShutUp__prac_snare_2.wav
    * url: http://www.freesound.org/people/TicTacShutUp/sounds/439/
    * license: Attribution
  * 438__TicTacShutUp__prac_sidestick.wav
    * url: http://www.freesound.org/people/TicTacShutUp/sounds/438/
    * license: Attribution
  * 437__TicTacShutUp__prac_sidestick_2.wav
    * url: http://www.freesound.org/people/TicTacShutUp/sounds/437/
    * license: Attribution
  * 436__TicTacShutUp__prac_ride.wav
    * url: http://www.freesound.org/people/TicTacShutUp/sounds/436/
    * license: Attribution
  * 435__TicTacShutUp__prac_ride_bell.wav
    * url: http://www.freesound.org/people/TicTacShutUp/sounds/435/
    * license: Attribution
  * 434__TicTacShutUp__prac_ride_bell_loud.wav
    * url: http://www.freesound.org/people/TicTacShutUp/sounds/434/
    * license: Attribution
  * 433__TicTacShutUp__prac_perc_5.wav
    * url: http://www.freesound.org/people/TicTacShutUp/sounds/433/
    * license: Attribution
  * 431__TicTacShutUp__prac_perc_3.wav
    * url: http://www.freesound.org/people/TicTacShutUp/sounds/431/
    * license: Attribution
  * 430__TicTacShutUp__prac_perc_2.wav
    * url: http://www.freesound.org/people/TicTacShutUp/sounds/430/
    * license: Attribution
  * 429__TicTacShutUp__prac_perc_1.wav
    * url: http://www.freesound.org/people/TicTacShutUp/sounds/429/
    * license: Attribution
  * 428__TicTacShutUp__prac_kick.wav
    * url: http://www.freesound.org/people/TicTacShutUp/sounds/428/
    * license: Attribution
  * 427__TicTacShutUp__prac_kick_light.wav
    * url: http://www.freesound.org/people/TicTacShutUp/sounds/427/
    * license: Attribution
  * 426__TicTacShutUp__prac_hat.wav
    * url: http://www.freesound.org/people/TicTacShutUp/sounds/426/
    * license: Attribution
  * 425__TicTacShutUp__prac_hat_open.wav
    * url: http://www.freesound.org/people/TicTacShutUp/sounds/425/
    * license: Attribution
  * 424__TicTacShutUp__prac_hat_open_3.wav
    * url: http://www.freesound.org/people/TicTacShutUp/sounds/424/
    * license: Attribution
  * 423__TicTacShutUp__prac_hat_open_2.wav
    * url: http://www.freesound.org/people/TicTacShutUp/sounds/423/
    * license: Attribution
  * 422__TicTacShutUp__prac_hat_3.wav
    * url: http://www.freesound.org/people/TicTacShutUp/sounds/422/
    * license: Attribution
  * 421__TicTacShutUp__prac_hat_2.wav
    * url: http://www.freesound.org/people/TicTacShutUp/sounds/421/
    * license: Attribution

